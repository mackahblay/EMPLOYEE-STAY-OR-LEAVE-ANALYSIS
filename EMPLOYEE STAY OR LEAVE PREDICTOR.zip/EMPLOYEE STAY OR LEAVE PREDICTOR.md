**Melchizedek Ackah-Blay**

December 2, 2024

*importing libraries*


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.style as style
style.use('ggplot')
import seaborn as sns
from sklearn.model_selection import train_test_split as t
```

*loading dataset*


```python
df = pd.read_csv(r'/Users/melki/Desktop/Employee.csv')
```

*displaying sample data*


```python
df.sample(7)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Education</th>
      <th>JoiningYear</th>
      <th>City</th>
      <th>PaymentTier</th>
      <th>Age</th>
      <th>Gender</th>
      <th>EverBenched</th>
      <th>ExperienceInCurrentDomain</th>
      <th>LeaveOrNot</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2698</th>
      <td>Bachelors</td>
      <td>2014</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>28</td>
      <td>Male</td>
      <td>No</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3205</th>
      <td>Masters</td>
      <td>2015</td>
      <td>Pune</td>
      <td>2</td>
      <td>33</td>
      <td>Male</td>
      <td>No</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1722</th>
      <td>Masters</td>
      <td>2017</td>
      <td>Pune</td>
      <td>2</td>
      <td>25</td>
      <td>Male</td>
      <td>No</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2921</th>
      <td>Bachelors</td>
      <td>2013</td>
      <td>Pune</td>
      <td>2</td>
      <td>28</td>
      <td>Female</td>
      <td>No</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1126</th>
      <td>Bachelors</td>
      <td>2013</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>28</td>
      <td>Male</td>
      <td>No</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3911</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>36</td>
      <td>Male</td>
      <td>No</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>234</th>
      <td>Masters</td>
      <td>2015</td>
      <td>Pune</td>
      <td>2</td>
      <td>25</td>
      <td>Female</td>
      <td>No</td>
      <td>3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



*looking at shape of the data*


```python
df.shape
```




    (4653, 9)



*looking at data types summary*


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4653 entries, 0 to 4652
    Data columns (total 9 columns):
     #   Column                     Non-Null Count  Dtype 
    ---  ------                     --------------  ----- 
     0   Education                  4653 non-null   object
     1   JoiningYear                4653 non-null   int64 
     2   City                       4653 non-null   object
     3   PaymentTier                4653 non-null   int64 
     4   Age                        4653 non-null   int64 
     5   Gender                     4653 non-null   object
     6   EverBenched                4653 non-null   object
     7   ExperienceInCurrentDomain  4653 non-null   int64 
     8   LeaveOrNot                 4653 non-null   int64 
    dtypes: int64(5), object(4)
    memory usage: 327.3+ KB


*looking for null values*


```python
df.isna().sum()
```




    Education                    0
    JoiningYear                  0
    City                         0
    PaymentTier                  0
    Age                          0
    Gender                       0
    EverBenched                  0
    ExperienceInCurrentDomain    0
    LeaveOrNot                   0
    dtype: int64



*looking for duplicates*


```python
df.duplicated().sum()
```




    1889



*drop duplicated rows*


```python
df.drop_duplicates(inplace = True)
```

*looking at the new shape*


```python
df.shape
```




    (2764, 9)



*looking at summary statistics*


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>JoiningYear</th>
      <th>PaymentTier</th>
      <th>Age</th>
      <th>ExperienceInCurrentDomain</th>
      <th>LeaveOrNot</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2764.000000</td>
      <td>2764.000000</td>
      <td>2764.000000</td>
      <td>2764.000000</td>
      <td>2764.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2015.090449</td>
      <td>2.636035</td>
      <td>30.952967</td>
      <td>2.644356</td>
      <td>0.393632</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.885943</td>
      <td>0.624001</td>
      <td>5.108872</td>
      <td>1.610610</td>
      <td>0.488643</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2012.000000</td>
      <td>1.000000</td>
      <td>22.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2013.000000</td>
      <td>2.000000</td>
      <td>27.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2015.000000</td>
      <td>3.000000</td>
      <td>30.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2017.000000</td>
      <td>3.000000</td>
      <td>35.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2018.000000</td>
      <td>3.000000</td>
      <td>41.000000</td>
      <td>7.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



## EXPLORATORY ANALYSIS

a*nalyzing mean age of people with degrees*


```python
df.groupby('Education')['Age'].mean().sort_values(ascending = False)
```




    Education
    Bachelors    31.306443
    Masters      30.149137
    PHD          29.769231
    Name: Age, dtype: float64



*analyzing employees who have been at the company the longest*


```python
df.sort_values(by = 'JoiningYear', ascending = True).head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Education</th>
      <th>JoiningYear</th>
      <th>City</th>
      <th>PaymentTier</th>
      <th>Age</th>
      <th>Gender</th>
      <th>EverBenched</th>
      <th>ExperienceInCurrentDomain</th>
      <th>LeaveOrNot</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4651</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>30</td>
      <td>Male</td>
      <td>Yes</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3052</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>34</td>
      <td>Male</td>
      <td>No</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3054</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>39</td>
      <td>Female</td>
      <td>No</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3055</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>41</td>
      <td>Male</td>
      <td>No</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3058</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>33</td>
      <td>Male</td>
      <td>No</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>415</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Pune</td>
      <td>3</td>
      <td>27</td>
      <td>Female</td>
      <td>No</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3079</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>37</td>
      <td>Female</td>
      <td>No</td>
      <td>5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3084</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Pune</td>
      <td>3</td>
      <td>31</td>
      <td>Male</td>
      <td>No</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3089</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Pune</td>
      <td>3</td>
      <td>34</td>
      <td>Male</td>
      <td>No</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3090</th>
      <td>Bachelors</td>
      <td>2012</td>
      <td>Bangalore</td>
      <td>3</td>
      <td>35</td>
      <td>Female</td>
      <td>No</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



*analyzing **education level** of employees*


```python
education_levels = df['Education'].value_counts(normalize = True)
education_levels
```




    Education
    Bachelors    0.713097
    Masters      0.230463
    PHD          0.056440
    Name: proportion, dtype: float64




```python
education_levels.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title('Degree Type Distribution')
plt.show()
```


    
![png](output_28_0.png)
    


*analyzing age distrbution*


```python
plt.hist(df['Age'], bins = 20, edgecolor = 'black', color = 'skyblue', density = True)
sns.kdeplot(df['Age'], color='navy', linewidth=1.5)
plt.title('Age Distribution of Employees\n')
plt.xlabel('\nAge')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_30_0.png)
    


*boxplot analyzing experience levels*


```python
plt.figure(figsize = (5, 4))
sns.boxplot( df['ExperienceInCurrentDomain'], showfliers = False, color = 'skyblue')
plt.title('Experience Levels Analysis\n', fontsize = 11)
plt.ylabel('Experience', fontsize = 9.5)
plt.show()
```


    
![png](output_32_0.png)
    


*comparing age and experience*


```python
sns.scatterplot(x = df['Age'], y = df['ExperienceInCurrentDomain'])
plt.title('Age vs Experience in Current Domain', fontsize = 11)
plt.ylabel('Experience', fontsize = 9.5)
plt.xlabel('Age', fontsize = 9.5)
plt.show()
```


    
![png](output_34_0.png)
    


*analyzing employees who left based on city*


```python
df.groupby('City')['LeaveOrNot'].value_counts().sort_values(ascending = False)
```




    City       LeaveOrNot
    Bangalore  0             761
    New Delhi  0             522
    Bangalore  1             410
    Pune       1             408
               0             393
    New Delhi  1             270
    Name: count, dtype: int64



*analyzing age based on Education and Gender*


```python
df.groupby(['Education', 'Gender'])['Age'].mean().sort_values(ascending = False)
```




    Education  Gender
    Bachelors  Male      31.619313
               Female    30.929530
    Masters    Female    30.348921
               Male      29.994429
    PHD        Male      29.795699
               Female    29.730159
    Name: Age, dtype: float64



*analyzing experience based on gender*


```python
cols = ['skyblue', 'pink']
sns.violinplot(x = 'Gender', y = 'ExperienceInCurrentDomain', data = df, palette = cols, hue = 'Gender', edgecolor = 'black')
plt.title('Experience by Gender', fontsize = 11)
plt.xlabel('\nGender', fontsize = 9.5)
plt.ylabel('Experience in Domain', fontsize = 9.5)
plt.show()
```


    
![png](output_40_0.png)
    


*analyzing employees who left or stayed based on gender*


```python
gender_ana = df.groupby('Gender')['LeaveOrNot'].value_counts().unstack()
gender_ana
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>LeaveOrNot</th>
      <th>0</th>
      <th>1</th>
    </tr>
    <tr>
      <th>Gender</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>621</td>
      <td>614</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>1055</td>
      <td>474</td>
    </tr>
  </tbody>
</table>
</div>




```python
gender_ana.plot(kind = 'bar', stacked = True, edgecolor = 'black')
plt.title('Left (1)  or Not (0) based on Gender', fontsize = 11)
plt.xlabel('\nGender', fontsize = 9.5)
plt.ylabel('Count', fontsize = 9.5)
plt.xticks(rotation = 0)
plt.show()
```


    
![png](output_43_0.png)
    


*joining year distribution*


```python
plt.figure(figsize = (8, 4))
plt.hist(df['JoiningYear'], color = 'pink', edgecolor = 'black', density = True, bins = 7)
sns.kdeplot(df['JoiningYear'], color = 'deeppink', linewidth = 1.5)
plt.title('Joining Year Distribution\n', fontsize = 11)
plt.xlabel('\nJoining Year', fontsize = 9.5)
plt.ylabel('Density', fontsize  = 9.5)
plt.show()
```


    
![png](output_45_0.png)
    


*experience in domain by gender*


```python
gender_edu_exp = df.groupby(['Gender', 'Education'])['ExperienceInCurrentDomain'].mean().unstack()
gender_edu_exp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Education</th>
      <th>Bachelors</th>
      <th>Masters</th>
      <th>PHD</th>
    </tr>
    <tr>
      <th>Gender</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>2.647651</td>
      <td>2.741007</td>
      <td>2.84127</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>2.564531</td>
      <td>2.715877</td>
      <td>2.83871</td>
    </tr>
  </tbody>
</table>
</div>



*visualizing experience by education and gender using bar graphs*


```python
gender_edu_exp.plot(kind = 'bar', color = ['pink', 'deeppink', 'red'], edgecolor = 'black')
plt.xticks(rotation = 0)
plt.title('Experience Levels by Gender and Education\n', fontsize = 11)
plt.xlabel('Gender', fontsize = 9.5)
plt.ylabel('\nAverage Expericence Level', fontsize = 9.5)
plt.show()
```


    
![png](output_49_0.png)
    


*visualizing experience by education and gender using box plots*


```python
gender_edu_exp.plot(kind = 'box', showfliers = False)
plt.xticks(rotation = 0)
plt.title('Experience Levels by Gender and Education\n', fontsize = 11)
plt.xlabel('Gender', fontsize = 9.5)
plt.ylabel('Average Expericence Level', fontsize = 9.5)
plt.show()
```


    
![png](output_51_0.png)
    


*analyzing age based on joining year and city*


```python
city_year_age = df.groupby(['JoiningYear', 'City'])['Age'].mean().unstack()
city_year_age
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>City</th>
      <th>Bangalore</th>
      <th>New Delhi</th>
      <th>Pune</th>
    </tr>
    <tr>
      <th>JoiningYear</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012</th>
      <td>31.993631</td>
      <td>29.657895</td>
      <td>30.333333</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>30.965714</td>
      <td>29.627273</td>
      <td>30.369369</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>31.562162</td>
      <td>29.662921</td>
      <td>31.171171</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>31.488372</td>
      <td>29.750000</td>
      <td>31.020833</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>31.931250</td>
      <td>29.916667</td>
      <td>30.743590</td>
    </tr>
    <tr>
      <th>2017</th>
      <td>31.583732</td>
      <td>31.032374</td>
      <td>30.680000</td>
    </tr>
    <tr>
      <th>2018</th>
      <td>31.389381</td>
      <td>30.388060</td>
      <td>30.949153</td>
    </tr>
  </tbody>
</table>
</div>




```python
city_year_age.plot(kind = 'line', marker = 'o', linewidth = 2.2, color = ['pink', 'skyblue', 'lightgreen'])
plt.title('Experience Levels by City and Joining Year\n', fontsize = 11)
plt.xlabel('Joining Year', fontsize = 9.5)
plt.ylabel('\nExperience', fontsize = 9.5)
plt.show()
```


    
![png](output_54_0.png)
    


## FEATURE ENGINEERING


```python
df.columns
```




    Index(['Education', 'JoiningYear', 'City', 'PaymentTier', 'Age', 'Gender',
           'EverBenched', 'ExperienceInCurrentDomain', 'LeaveOrNot'],
          dtype='object')




```python
x = df.drop(columns = ['LeaveOrNot'])
y = df['LeaveOrNot']
```


```python
x = x.drop(columns = ['JoiningYear', 'City', 'Age'])
x.sample(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Education</th>
      <th>PaymentTier</th>
      <th>Gender</th>
      <th>EverBenched</th>
      <th>ExperienceInCurrentDomain</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4009</th>
      <td>Bachelors</td>
      <td>1</td>
      <td>Female</td>
      <td>Yes</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1949</th>
      <td>Masters</td>
      <td>2</td>
      <td>Female</td>
      <td>No</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1493</th>
      <td>Masters</td>
      <td>3</td>
      <td>Female</td>
      <td>No</td>
      <td>5</td>
    </tr>
    <tr>
      <th>390</th>
      <td>Bachelors</td>
      <td>3</td>
      <td>Male</td>
      <td>No</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



label encoding the categorical x values


```python
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
```


```python
x['Education'] = encoder.fit_transform(x['Education'])
x['Gender'] = encoder.fit_transform(x['Gender'])
x['EverBenched'] = encoder.fit_transform(x['EverBenched'])
```


```python
x.sample(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Education</th>
      <th>PaymentTier</th>
      <th>Gender</th>
      <th>EverBenched</th>
      <th>ExperienceInCurrentDomain</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3856</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>401</th>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3781</th>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3364</th>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



splitting data into train and test


```python
x_train, x_test, y_train, y_test = t(x, y, test_size = 0.2, random_state = 1)
```

scaling data


```python
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
```


```python
items = [x_train, x_test, y_train, y_test]
names = ['x_train:', 'x_test:', 'y_train:', 'y_test:']
j = 0
for i, j in zip(items, names):
    print(j)
    print(len(i))
    print('\n')
```

    x_train:
    2211
    
    
    x_test:
    553
    
    
    y_train:
    2211
    
    
    y_test:
    553
    
    



```python
x_train_scaled = scaler.fit_transform(x_train)
x_test_scaled = scaler.fit_transform(x_test)
```


```python
from sklearn.metrics import accuracy_score
def evaluator(pred):
    print(f'\nthe accuracy is {round(accuracy_score(y_test, pred),9)}\n')
```

training logistic regression model


```python
from sklearn.linear_model import LogisticRegression
```


```python
log_model = LogisticRegression()
log_model.fit(x_train_scaled, y_train)
log_pred = log_model.predict(x_test_scaled)
```

evaluating logistic regression model


```python
evaluator(log_pred)
```

    
    the accuracy is 0.584087
    


training kneighbor gridsearch model


```python
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from xgboost import XGBClassifier
```


```python
knc_grid = {
    'n_neighbors':[3, 5, 8, 12],
    'weights' : ['uniform', 'distance', None]
}

random_forest_grid = {
    'n_estimators': [40, 50, 120, 200],
    'criterion' : ["gini", "entropy", "log_loss"]
}

adaboost_grid = {
    'n_estimators':[50, 100],
    'learning_rate':[0.5, 1.0, 1.5]
}

xg_grid = {
    'n_estimators':[50, 100, 75],
    'max_depth': [None, 5, 10, 30],
    'learning_rate': [0.04, 0.1, 0.2],
    'min_child_weight': [1, 3, 5]
}
```

**KNEIGHBORS MODEL**


```python
gridKNC = GridSearchCV(estimator = KNeighborsClassifier(), param_grid = knc_grid, cv = 5)
gridKNC.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-3 {color: black;background-color: white;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5, estimator=KNeighborsClassifier(),
             param_grid={&#x27;n_neighbors&#x27;: [3, 5, 8, 12],
                         &#x27;weights&#x27;: [&#x27;uniform&#x27;, &#x27;distance&#x27;, None]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=5, estimator=KNeighborsClassifier(),
             param_grid={&#x27;n_neighbors&#x27;: [3, 5, 8, 12],
                         &#x27;weights&#x27;: [&#x27;uniform&#x27;, &#x27;distance&#x27;, None]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-8" type="checkbox" ><label for="sk-estimator-id-8" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: KNeighborsClassifier</label><div class="sk-toggleable__content"><pre>KNeighborsClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-9" type="checkbox" ><label for="sk-estimator-id-9" class="sk-toggleable__label sk-toggleable__label-arrow">KNeighborsClassifier</label><div class="sk-toggleable__content"><pre>KNeighborsClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
gridKNC_pred = gridKNC.predict(x_test_scaled)
#evaluating model
evaluator(gridKNC_pred)
```

    
    the accuracy is 0.643761302
    


*analyzing model's best paramaters*


```python
gridKNC.best_params_
```




    {'n_neighbors': 12, 'weights': 'distance'}



**RANDOM FOREST MODEL**


```python
gridRFC = GridSearchCV(estimator = RandomForestClassifier(), param_grid = random_forest_grid, cv = 5)
gridRFC.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-4 {color: black;background-color: white;}#sk-container-id-4 pre{padding: 0;}#sk-container-id-4 div.sk-toggleable {background-color: white;}#sk-container-id-4 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-4 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-4 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-4 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-4 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-4 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-4 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-4 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-4 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-4 div.sk-item {position: relative;z-index: 1;}#sk-container-id-4 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-4 div.sk-item::before, #sk-container-id-4 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-4 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-4 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-4 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-4 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-4 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-4 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-4 div.sk-label-container {text-align: center;}#sk-container-id-4 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-4 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5, estimator=RandomForestClassifier(),
             param_grid={&#x27;criterion&#x27;: [&#x27;gini&#x27;, &#x27;entropy&#x27;, &#x27;log_loss&#x27;],
                         &#x27;n_estimators&#x27;: [40, 50, 120, 200]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-10" type="checkbox" ><label for="sk-estimator-id-10" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=5, estimator=RandomForestClassifier(),
             param_grid={&#x27;criterion&#x27;: [&#x27;gini&#x27;, &#x27;entropy&#x27;, &#x27;log_loss&#x27;],
                         &#x27;n_estimators&#x27;: [40, 50, 120, 200]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-11" type="checkbox" ><label for="sk-estimator-id-11" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-12" type="checkbox" ><label for="sk-estimator-id-12" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
gridRFC_pred = gridRFC.predict(x_test_scaled)
#evaluating model
evaluator(gridRFC_pred)
```

    
    the accuracy is 0.640145
    


*analyzing model's best paramaters*


```python
gridRFC.best_params_
```




    {'criterion': 'entropy', 'n_estimators': 120}



**ADABOOST MODEL 1**


```python
gridABC = GridSearchCV(estimator = AdaBoostClassifier(estimator = RandomForestClassifier()), param_grid = adaboost_grid, cv = 5)
gridABC.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-5 {color: black;background-color: white;}#sk-container-id-5 pre{padding: 0;}#sk-container-id-5 div.sk-toggleable {background-color: white;}#sk-container-id-5 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-5 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-5 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-5 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-5 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-5 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-5 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-5 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-5 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-5 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-5 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-5 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-5 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-5 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-5 div.sk-item {position: relative;z-index: 1;}#sk-container-id-5 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-5 div.sk-item::before, #sk-container-id-5 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-5 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-5 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-5 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-5 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-5 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-5 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-5 div.sk-label-container {text-align: center;}#sk-container-id-5 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-5 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-5" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5,
             estimator=AdaBoostClassifier(estimator=RandomForestClassifier()),
             param_grid={&#x27;learning_rate&#x27;: [0.5, 1.0, 1.5],
                         &#x27;n_estimators&#x27;: [50, 100]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-13" type="checkbox" ><label for="sk-estimator-id-13" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=5,
             estimator=AdaBoostClassifier(estimator=RandomForestClassifier()),
             param_grid={&#x27;learning_rate&#x27;: [0.5, 1.0, 1.5],
                         &#x27;n_estimators&#x27;: [50, 100]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-14" type="checkbox" ><label for="sk-estimator-id-14" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: AdaBoostClassifier</label><div class="sk-toggleable__content"><pre>AdaBoostClassifier(estimator=RandomForestClassifier())</pre></div></div></div><div class="sk-serial"><div class="sk-item sk-dashed-wrapped"><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-15" type="checkbox" ><label for="sk-estimator-id-15" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-16" type="checkbox" ><label for="sk-estimator-id-16" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>




```python
gridABC_pred = gridABC.predict(x_test_scaled)
#evaluating model
evaluator(gridABC_pred)
```

    
    the accuracy is 0.636528
    


*analyzing model's best paramaters*


```python
gridABC.best_params_
```




    {'learning_rate': 1.0, 'n_estimators': 50}



**ADABOOST MODEL 2**


```python
from sklearn.tree import DecisionTreeClassifier
gridABC2 = GridSearchCV(estimator = AdaBoostClassifier(estimator = DecisionTreeClassifier()), param_grid = adaboost_grid, cv = 5)
gridABC2.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-6 {color: black;background-color: white;}#sk-container-id-6 pre{padding: 0;}#sk-container-id-6 div.sk-toggleable {background-color: white;}#sk-container-id-6 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-6 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-6 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-6 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-6 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-6 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-6 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-6 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-6 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-6 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-6 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-6 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-6 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-6 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-6 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-6 div.sk-item {position: relative;z-index: 1;}#sk-container-id-6 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-6 div.sk-item::before, #sk-container-id-6 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-6 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-6 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-6 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-6 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-6 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-6 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-6 div.sk-label-container {text-align: center;}#sk-container-id-6 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-6 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-6" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5,
             estimator=AdaBoostClassifier(estimator=DecisionTreeClassifier()),
             param_grid={&#x27;learning_rate&#x27;: [0.5, 1.0, 1.5],
                         &#x27;n_estimators&#x27;: [50, 100]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-17" type="checkbox" ><label for="sk-estimator-id-17" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=5,
             estimator=AdaBoostClassifier(estimator=DecisionTreeClassifier()),
             param_grid={&#x27;learning_rate&#x27;: [0.5, 1.0, 1.5],
                         &#x27;n_estimators&#x27;: [50, 100]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-18" type="checkbox" ><label for="sk-estimator-id-18" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: AdaBoostClassifier</label><div class="sk-toggleable__content"><pre>AdaBoostClassifier(estimator=DecisionTreeClassifier())</pre></div></div></div><div class="sk-serial"><div class="sk-item sk-dashed-wrapped"><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-19" type="checkbox" ><label for="sk-estimator-id-19" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: DecisionTreeClassifier</label><div class="sk-toggleable__content"><pre>DecisionTreeClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-20" type="checkbox" ><label for="sk-estimator-id-20" class="sk-toggleable__label sk-toggleable__label-arrow">DecisionTreeClassifier</label><div class="sk-toggleable__content"><pre>DecisionTreeClassifier()</pre></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>




```python
gridABC2_pred = gridABC2.predict(x_test_scaled)
#evaluating model
evaluator(gridABC2_pred)
```

    
    the accuracy is 0.643761302
    


*analyzing model's best paramaters*


```python
gridABC2.best_params_
```




    {'learning_rate': 0.5, 'n_estimators': 100}



**XGBOOST MODEL**


```python
gridXG = GridSearchCV(estimator = XGBClassifier(), param_grid = xg_grid, cv = 5)
gridXG.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-7 {color: black;background-color: white;}#sk-container-id-7 pre{padding: 0;}#sk-container-id-7 div.sk-toggleable {background-color: white;}#sk-container-id-7 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-7 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-7 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-7 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-7 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-7 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-7 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-7 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-7 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-7 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-7 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-7 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-7 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-7 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-7 div.sk-item {position: relative;z-index: 1;}#sk-container-id-7 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-7 div.sk-item::before, #sk-container-id-7 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-7 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-7 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-7 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-7 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-7 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-7 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-7 div.sk-label-container {text-align: center;}#sk-container-id-7 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-7 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-7" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5,
             estimator=XGBClassifier(base_score=None, booster=None,
                                     callbacks=None, colsample_bylevel=None,
                                     colsample_bynode=None,
                                     colsample_bytree=None, device=None,
                                     early_stopping_rounds=None,
                                     enable_categorical=False, eval_metric=None,
                                     feature_types=None, gamma=None,
                                     grow_policy=None, importance_type=None,
                                     interaction_constraints=None,
                                     learning_rate=None,...
                                     max_cat_to_onehot=None,
                                     max_delta_step=None, max_depth=None,
                                     max_leaves=None, min_child_weight=None,
                                     missing=nan, monotone_constraints=None,
                                     multi_strategy=None, n_estimators=None,
                                     n_jobs=None, num_parallel_tree=None,
                                     random_state=None, ...),
             param_grid={&#x27;learning_rate&#x27;: [0.04, 0.1, 0.2],
                         &#x27;max_depth&#x27;: [None, 5, 10, 30],
                         &#x27;min_child_weight&#x27;: [1, 3, 5],
                         &#x27;n_estimators&#x27;: [50, 100, 75]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-21" type="checkbox" ><label for="sk-estimator-id-21" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=5,
             estimator=XGBClassifier(base_score=None, booster=None,
                                     callbacks=None, colsample_bylevel=None,
                                     colsample_bynode=None,
                                     colsample_bytree=None, device=None,
                                     early_stopping_rounds=None,
                                     enable_categorical=False, eval_metric=None,
                                     feature_types=None, gamma=None,
                                     grow_policy=None, importance_type=None,
                                     interaction_constraints=None,
                                     learning_rate=None,...
                                     max_cat_to_onehot=None,
                                     max_delta_step=None, max_depth=None,
                                     max_leaves=None, min_child_weight=None,
                                     missing=nan, monotone_constraints=None,
                                     multi_strategy=None, n_estimators=None,
                                     n_jobs=None, num_parallel_tree=None,
                                     random_state=None, ...),
             param_grid={&#x27;learning_rate&#x27;: [0.04, 0.1, 0.2],
                         &#x27;max_depth&#x27;: [None, 5, 10, 30],
                         &#x27;min_child_weight&#x27;: [1, 3, 5],
                         &#x27;n_estimators&#x27;: [50, 100, 75]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-22" type="checkbox" ><label for="sk-estimator-id-22" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: XGBClassifier</label><div class="sk-toggleable__content"><pre>XGBClassifier(base_score=None, booster=None, callbacks=None,
              colsample_bylevel=None, colsample_bynode=None,
              colsample_bytree=None, device=None, early_stopping_rounds=None,
              enable_categorical=False, eval_metric=None, feature_types=None,
              gamma=None, grow_policy=None, importance_type=None,
              interaction_constraints=None, learning_rate=None, max_bin=None,
              max_cat_threshold=None, max_cat_to_onehot=None,
              max_delta_step=None, max_depth=None, max_leaves=None,
              min_child_weight=None, missing=nan, monotone_constraints=None,
              multi_strategy=None, n_estimators=None, n_jobs=None,
              num_parallel_tree=None, random_state=None, ...)</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-23" type="checkbox" ><label for="sk-estimator-id-23" class="sk-toggleable__label sk-toggleable__label-arrow">XGBClassifier</label><div class="sk-toggleable__content"><pre>XGBClassifier(base_score=None, booster=None, callbacks=None,
              colsample_bylevel=None, colsample_bynode=None,
              colsample_bytree=None, device=None, early_stopping_rounds=None,
              enable_categorical=False, eval_metric=None, feature_types=None,
              gamma=None, grow_policy=None, importance_type=None,
              interaction_constraints=None, learning_rate=None, max_bin=None,
              max_cat_threshold=None, max_cat_to_onehot=None,
              max_delta_step=None, max_depth=None, max_leaves=None,
              min_child_weight=None, missing=nan, monotone_constraints=None,
              multi_strategy=None, n_estimators=None, n_jobs=None,
              num_parallel_tree=None, random_state=None, ...)</pre></div></div></div></div></div></div></div></div></div></div>




```python
gridXG_pred = gridXG.predict(x_test_scaled)
#evaluating model
evaluator(gridXG_pred)
```

    
    the accuracy is 0.605787
    


*analyzing model's best paramaters*


```python
gridXG.best_params_
```




    {'learning_rate': 0.04,
     'max_depth': 5,
     'min_child_weight': 5,
     'n_estimators': 75}



**SUPPORT VECTOR MODEL**


```python
sv_grid = {
    'C': [0.1, 1, 10, 100],
    'kernel': ['linear', 'poly', 'sigmoid'],
    'gamma': ['scale', 'auto', 0.1], 
}
```


```python
from sklearn.svm import SVC
```


```python
gridSVC = GridSearchCV(SVC(), param_grid = sv_grid)
gridSVC.fit(x_train_scaled, y_train)
```




<style>#sk-container-id-8 {color: black;background-color: white;}#sk-container-id-8 pre{padding: 0;}#sk-container-id-8 div.sk-toggleable {background-color: white;}#sk-container-id-8 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-8 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-8 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-8 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-8 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-8 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-8 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-8 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-8 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-8 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-8 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-8 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-8 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-8 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-8 div.sk-item {position: relative;z-index: 1;}#sk-container-id-8 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-8 div.sk-item::before, #sk-container-id-8 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-8 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-8 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-8 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-8 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-8 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-8 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-8 div.sk-label-container {text-align: center;}#sk-container-id-8 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-8 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-8" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(estimator=SVC(),
             param_grid={&#x27;C&#x27;: [0.1, 1, 10, 100],
                         &#x27;gamma&#x27;: [&#x27;scale&#x27;, &#x27;auto&#x27;, 0.1],
                         &#x27;kernel&#x27;: [&#x27;linear&#x27;, &#x27;poly&#x27;, &#x27;sigmoid&#x27;]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-24" type="checkbox" ><label for="sk-estimator-id-24" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(estimator=SVC(),
             param_grid={&#x27;C&#x27;: [0.1, 1, 10, 100],
                         &#x27;gamma&#x27;: [&#x27;scale&#x27;, &#x27;auto&#x27;, 0.1],
                         &#x27;kernel&#x27;: [&#x27;linear&#x27;, &#x27;poly&#x27;, &#x27;sigmoid&#x27;]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-25" type="checkbox" ><label for="sk-estimator-id-25" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: SVC</label><div class="sk-toggleable__content"><pre>SVC()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-26" type="checkbox" ><label for="sk-estimator-id-26" class="sk-toggleable__label sk-toggleable__label-arrow">SVC</label><div class="sk-toggleable__content"><pre>SVC()</pre></div></div></div></div></div></div></div></div></div></div>




```python
gridSVC_pred = gridSVC.predict(x_test_scaled)
#evaluating model
evaluator(gridSVC_pred)
```

    
    the accuracy is 0.636528
    


*analyzing model's best paramaters*


```python
gridSVC.best_params_
```




    {'C': 10, 'gamma': 'scale', 'kernel': 'poly'}



**FINAL EVALUATIONS**

*AdaBoost and KNeighbor Classifier models performed the best.*

*As a result, I will compare them using other metrics: precision_score, recall_score, and F1 score*


```python
from sklearn.metrics import precision_score, recall_score, f1_score
```


```python
def evaluator2(pred):
    print(f'precision score: {round(precision_score(y_test, pred), 3)}')
    print(f'recall score: {round(recall_score(y_test, pred),3)}')
    print(f'f1 score: {round(f1_score(y_test, pred),3)}')
```

re-evaluating kneighbor classifier model


```python
evaluator2(gridKNC_pred)
```

    precision score: 0.658
    recall score: 0.395
    f1 score: 0.494


re-evaluating adaboost classifier model


```python
evaluator2(gridABC2_pred)
```

    precision score: 0.677
    recall score: 0.362
    f1 score: 0.472


**FINAL MODEL EVALUATIONS**

*the gridsearchCV kneighbor classifier model performed **better** at the end*


```python
best_model = gridKNC.best_estimator_
best_model
```




<style>#sk-container-id-10 {color: black;background-color: white;}#sk-container-id-10 pre{padding: 0;}#sk-container-id-10 div.sk-toggleable {background-color: white;}#sk-container-id-10 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-10 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-10 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-10 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-10 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-10 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-10 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-10 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-10 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-10 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-10 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-10 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-10 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-10 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-10 div.sk-item {position: relative;z-index: 1;}#sk-container-id-10 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-10 div.sk-item::before, #sk-container-id-10 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-10 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-10 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-10 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-10 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-10 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-10 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-10 div.sk-label-container {text-align: center;}#sk-container-id-10 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-10 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-10" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>KNeighborsClassifier(n_neighbors=12, weights=&#x27;distance&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-31" type="checkbox" checked><label for="sk-estimator-id-31" class="sk-toggleable__label sk-toggleable__label-arrow">KNeighborsClassifier</label><div class="sk-toggleable__content"><pre>KNeighborsClassifier(n_neighbors=12, weights=&#x27;distance&#x27;)</pre></div></div></div></div></div>




```python
from sklearn.inspection import permutation_importance
```


```python
result = permutation_importance(best_model, x_train, y_train, n_repeats = 10, random_state = 1)
```

    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(
    /opt/anaconda3/lib/python3.11/site-packages/sklearn/base.py:432: UserWarning: X has feature names, but KNeighborsClassifier was fitted without feature names
      warnings.warn(


*dataFrame to display the feature importances*


```python
feature_importance_df = pd.DataFrame({
    'Feature': x_train.columns,
    'Importance': result.importances_mean
}).sort_values(by='Importance', ascending=False)

print(feature_importance_df)
```

                         Feature  Importance
    0                  Education    0.021348
    4  ExperienceInCurrentDomain    0.005427
    1                PaymentTier    0.000724
    3                EverBenched   -0.006242
    2                     Gender   -0.018318


**CONCLUSION**


the factors that impacted if employees would leave their job were

**1.** Education Level

**2.** Experience Level in their current domain

**3.** Payment Tier

**4.** If they were ever benched

**5.** Gender 



**RECOMMENDATIONS**

at the very least, the company should ensure it's most **educated** employees with the **highest level of experience** maintain a positive relationship with the company, so as to not lose their talents to competitors
